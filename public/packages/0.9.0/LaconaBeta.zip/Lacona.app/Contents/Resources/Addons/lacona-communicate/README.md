# lacona-command-communicate
Lacona Command for initiating facetime calls, phone calls, text messages, and more
