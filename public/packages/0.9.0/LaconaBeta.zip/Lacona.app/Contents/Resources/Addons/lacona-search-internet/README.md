# lacona-command-search-internet
Lacona command to open web searches
