# lacona-command-events
Lacona Command for manipulating Events and Reminders on the system
