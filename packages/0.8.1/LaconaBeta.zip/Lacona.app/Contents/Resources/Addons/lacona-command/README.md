# lacona-command-open
Lacona Command for opening apps, files, and urls. It also handles quitting apps, switching between apps and browser tabs, closing browser tabs, and more.
