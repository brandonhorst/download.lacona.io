# lacona-command-translate
Lacona Command for translating strings and URLs
